package com.salesianostriana.dam.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.dam.model.Apartado;
import com.salesianostriana.dam.model.Informe;
import com.salesianostriana.dam.model.Residente;
import com.salesianostriana.dam.service.ApartadoService;
import com.salesianostriana.dam.service.InformeService;
import com.salesianostriana.dam.service.ResidenteService;

@Controller
public class InformesController {

	@Autowired
	InformeService informeService;
	
	@Autowired
	ResidenteService residenteService;
	
	@Autowired
	ApartadoService apartadoService;
	
	
	@GetMapping("/")
	public String index(Model model) {

		model.addAttribute("informe", informeService.findAllByOrderByFechaDesc());
		return "index";
		
	}
	
	@GetMapping("/gestionInformes")
	public String GestionInformes(Model model) {

		model.addAttribute("informe", informeService.findAll());
		return "gestion-informes";
		
	}
	
	//Agregar Informe

		@GetMapping("/agregarInforme")
		public String agregarInforme(Model model) {
			
			
			Informe informe = new Informe();
			List<Apartado> listaApartados = new ArrayList<Apartado>();
			listaApartados.add(new Apartado("clinico"));
			listaApartados.add(new Apartado("funcional"));
			listaApartados.add(new Apartado("psiquico"));
			listaApartados.add(new Apartado("social"));
			listaApartados.add(new Apartado("ocupacional"));
			
			informe.setListaApartados(listaApartados);
			
			model.addAttribute("agregarInforme", informe);
			model.addAttribute("listadoResidentes", residenteService.findAll());
			
			
			return "agregar-informe";
		}

		
		@PostMapping("/addInforme")
		public String submitInforme(@Valid @ModelAttribute("agregarInforme") Informe informe, Model model) {

			
			informeService.addInforme(informe);
			
			Residente residente = residenteService.findById(informe.getResidente().getId());
			residente.addInforme(informe);
			
			residenteService.addResidente(residente);
	
			
			return "redirect:/gestionInformes";
		}
		
	
		

		@GetMapping("/editarInforme/{id}")
        public String editarInforme(@PathVariable("id") long id, Model model) {

            Informe informe = new Informe();
            List<Apartado> listaApartados = new ArrayList<Apartado>();
            listaApartados.add(new Apartado("clinico"));
            listaApartados.add(new Apartado("funcional"));
            listaApartados.add(new Apartado("psiquico"));
            listaApartados.add(new Apartado("social"));
            listaApartados.add(new Apartado("ocupacional"));

            informe.setListaApartados(listaApartados);

            model.addAttribute("listadoResidentes", residenteService.findAll());
            model.addAttribute("editarInforme", informe);

            return "editar-informe";
        }

        @PostMapping("/{id}/editInforme")
        public String editInforme(@ModelAttribute("editarInforme") Informe informe, Model model) {

            informeService.updateInforme(informe);

            return "redirect:/gestionInformes";
        }
		
	
		
		@GetMapping("/borrarInforme/{id}")
		public String borrarInforme(@PathVariable("id") long id, Model model) {
			informeService.deleteInforme(informeService.findById(id));
			
			return "redirect:/gestionInformes";
		}
		
		
		@GetMapping("/mostrarInforme/{id}")
	    public String mostrarInforme(@PathVariable("id") Long id, Model model) {

	        Informe informe = informeService.findById(id);
	        
            List<Apartado> listaApartados = new ArrayList<Apartado>();
            listaApartados.add(new Apartado("clinico"));
            listaApartados.add(new Apartado("funcional"));
            listaApartados.add(new Apartado("psiquico"));
            listaApartados.add(new Apartado("social"));
            listaApartados.add(new Apartado("ocupacional"));

            informe.setListaApartados(listaApartados);

	      
	            model.addAttribute("mostrarInforme", informe);

	            return "ver-informe";
	        
	    }
		
}
