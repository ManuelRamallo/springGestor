package com.salesianostriana.dam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.salesianostriana.dam.model.Informe;
import com.salesianostriana.dam.service.InformeService;

@Controller
public class InformesController {

	@Autowired
	InformeService informeService;
	
	@GetMapping("/gestionInformes")
	public String GestionInformes(Model model) {

		model.addAttribute("informe", informeService.findAll());
		return "gestion-informes";
		
	}
	
	//Agregar Informe

		@GetMapping("/agregarInforme")
		public String agregarInforme(Model model) {
			Informe informe = new Informe();

			model.addAttribute("agregarInforme", informe);
			return "agregar-informe";
		}

		
		@PostMapping("/addInforme")
		public String submitInforme(@ModelAttribute("agregarInforme") Informe informe, Model model) {

			model.addAttribute("informe", informe);
			informeService.addInforme(informe);

			return "redirect:/gestionInformes";
		}
		
		//Editar Residente
		

		@GetMapping("/editarInforme/{id}")
		public String editarInforme(@PathVariable("id") long id, Model model) {

			Informe informe = informeService.findById(id);
			model.addAttribute("informeForm", informe);

			return "editar-informe";
		}

		@PostMapping("/{id}/editInforme")
		public String editInforme(@ModelAttribute("informeForm") Informe informe, Model model) {

			informeService.updateInforme(informe);

			return "redirect:/gestionInformes";
		}
		
		
		//Borrar Residente
		
		@GetMapping("/borrarInforme/{id}")
		public String borrarInforme(@PathVariable("id") long id, Model model) {
			informeService.deleteInforme(informeService.findById(id));
			
			return "redirect:/gestionInformes";
		}
}
